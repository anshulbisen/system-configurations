# darkyog
sqlyog dark theme customization like a darkula

![Screenshot](https://aplab.ru/capsule/storage/920/f99/411/920f994114f63ee4ee0e1e84baf7eb81.png "Screenshot")

php executable needed

1 Download php http://windows.php.net/download 

and unzip into c:\php\

2 download darkyog and unzip into any directory

3 close all sqlyog sessions and close sqlyog

4 run bin/darkyog.bat under the current user (not the admin)

5 start sqlyog
